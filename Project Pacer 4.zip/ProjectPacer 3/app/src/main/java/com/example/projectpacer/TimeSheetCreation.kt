package com.example.projectpacer

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.icu.util.Calendar
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException
import java.util.*


class TimeSheetCreation : AppCompatActivity() {

    private lateinit var categorySpinner: Spinner
    private lateinit var descriptionEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var AddCategoryButton: ImageButton
    private lateinit var cancelButton: Button
    private lateinit var selectedImage: ImageView
    private var selectedImageBitmap: Bitmap? = null

    private lateinit var startDateButton: Button
    private lateinit var startDateTextView: TextView
    private var selectedStartdate: String = ""

    private lateinit var endDateButton: Button
    private lateinit var endDateTextView: TextView
    private var selectedenddate: String = ""

    private lateinit var startTimeButton: Button
    private lateinit var startTimeTextView: TextView
    private var selectedStartTime: String = ""

    private lateinit var endTimeButton: Button
    private lateinit var endTimeTextView: TextView
    private var selectedEndTime: String = ""


    private val categories = CategoriesActivity.CategoriesManager.categoryListFull.map { it.name }

    var email = HomeActivity.UserManager.loggedInUser?.email.toString()

    @SuppressLint("SuspiciousIndentation", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_time_sheet_creation)

        selectedImage = findViewById(R.id.selectedImage)

        categorySpinner = findViewById(R.id.categorySpinner)
        descriptionEditText = findViewById(R.id.descriptionEditText)
        saveButton = findViewById(R.id.saveButton)
        cancelButton = findViewById(R.id.cancelButton)

        //Date
        startDateButton = findViewById(R.id.startDateButton)
        startDateTextView = findViewById(R.id.startDateTextView)

        startDateButton.setOnClickListener {
            showStartDatePickerDialog()
        }
        endDateButton = findViewById(R.id.endDateButton)
        endDateTextView = findViewById(R.id.endDateTextView)

        endDateButton.setOnClickListener {
            showEndDatePickerDialog()
        }
        // Time
        startTimeButton = findViewById(R.id.startTimeButton)
        startTimeTextView = findViewById(R.id.startTimeTextView)

        startTimeButton.setOnClickListener {
            showStartTimePickerDialog()
        }
        endTimeButton = findViewById(R.id.endTimeButton)
        endTimeTextView = findViewById(R.id.endTimeTextView)

        endTimeButton.setOnClickListener {
            showEndTimePickerDialog()
        }

        //category
        AddCategoryButton = findViewById(R.id.Addcategorybutton)
        AddCategoryButton.setOnClickListener {
            val intent = Intent(this, CategoriesActivity::class.java)
            startActivity(intent)

        }


        //image
        val imageButton: Button = findViewById(R.id.imageButton)
        imageButton.setOnClickListener {
            openImagePicker()
        }
        val userEmail1 = HomeActivity.UserManager.loggedInUser?.email
        val filteredTimeSheetEntries = CategoriesActivity.CategoriesManager.categoryListFull.filter { entry ->
            entry.email == userEmail1
        }

        // Set up the category spinner with the adapter

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, filteredTimeSheetEntries.map { it.name })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter

        //Set the text color of the Spinner's selected view (not a drop down list view)
        //Set the text color of the Spinner's selected view (not a drop down list view)
        categorySpinner.setSelection(0, true)
        val v: View = categorySpinner.getSelectedView()
        (v as TextView).setTextColor(Color.BLACK)

        //Set the listener for when each option is clicked.

        //Set the listener for when each option is clicked.
        categorySpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View,
                position: Int,
                id: Long
            ) {
                //Change the selected item's text color
                (view as TextView).setTextColor(Color.BLACK)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        saveButton.setOnClickListener {


            val endTime = selectedEndTime
            val selectedCategory = categorySpinner.selectedItem.toString()
            val description = descriptionEditText.text.toString()

            val image = R.drawable.logo_name
            // Get the selected date
            val startDate = selectedStartdate

            val endDate = selectedenddate
            // Get the selected date
            val currentTime = selectedStartTime

            // Create the timesheet data object
            val timeSheetEntry =
                TimeSheetData(
                    selectedImageBitmap,
                    startDate,
                    endDate,
                    currentTime,
                    endTime,
                    selectedCategory,
                    description,
                    email
                )
                // adding timesheet objects to timesheet list
                TimeSheetActivity.TimeSheetManager.timeSheetEntries.add(timeSheetEntry)

            val intent = Intent(this, TimeSheetActivity::class.java)
            startActivity(intent)

        }

        cancelButton.setOnClickListener {
            val intent = Intent(this, TimeSheetActivity::class.java)
            startActivity(intent)
        }


    }
    //this was taken from YouTube
    //author: Android Coding
    //Link: https://www.youtube.com/watch?v=Xf5K2Ls07cs
    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, IMAGE_PICKER_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == IMAGE_PICKER_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val imageUri = data?.data
            var bitmap = getBitmapFromUri(imageUri)
            selectedImageBitmap = bitmap

        }
    }

    private fun getBitmapFromUri(uri: Uri?): Bitmap? {
        uri?.let {
            return try {
                val inputStream = contentResolver.openInputStream(uri)
                BitmapFactory.decodeStream(inputStream)
            } catch (e: IOException) {
                e.printStackTrace()
                null
            }
        }
        return null
    }
    companion object {
        private const val IMAGE_PICKER_REQUEST_CODE = 100
    }

    //this was taken from YouTube
    //author:Coding in FLow
    //Link: https://www.youtube.com/watch?v=QMwaNN_aM3U
    private fun showStartTimePickerDialog() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, selectedHour, selectedMinute ->
                 selectedStartTime = String.format("%02d:%02d", selectedHour, selectedMinute)
                startTimeButton.text = selectedStartTime
            },
            hour,
            minute,
            true
        )

        timePickerDialog.show()
    }

    //this was taken from YouTube
    //author:Coding in FLow
    //Link: https://www.youtube.com/watch?v=QMwaNN_aM3U
    private fun showEndTimePickerDialog() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, selectedHour, selectedMinute ->
                selectedEndTime = String.format("%02d:%02d", selectedHour, selectedMinute)
                endTimeButton.text = selectedEndTime
            },
            hour,
            minute,
            true
        )

        timePickerDialog.show()
    }

    //this was taken from YouTube
    //author:Coding in FLow
    //Link: https://www.youtube.com/watch?v=33BFCdL0Di0
    private fun showStartDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, selectedYear, selectedMonth, selectedDay ->
                val formattedDate = String.format("%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay)
                selectedStartdate = formattedDate
                //change made here
                startDateButton.text = selectedStartdate
            },
            year,
            month,
            day
        )

        datePickerDialog.show()
    }
    //this was taken from YouTube
    //author:Coding in FLow
    //Link: https://www.youtube.com/watch?v=33BFCdL0Di0
    private fun showEndDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, selectedYear, selectedMonth, selectedDay ->
                val formattedDate = String.format("%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay)
                selectedenddate = formattedDate
                endDateButton.text = selectedenddate
            },
            year,
            month,
            day
        )

        datePickerDialog.show()
    }


}

