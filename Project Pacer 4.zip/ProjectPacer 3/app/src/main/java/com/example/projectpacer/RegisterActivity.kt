//package com.example.codeseasy.com.firebaseauth
package com.example.projectpacer

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth


class RegisterActivity : AppCompatActivity() {

    private lateinit var NameEditText: EditText
    private lateinit var surnameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var auth: FirebaseAuth
// ...
// Initialize Firebase Auth
    auth = Firebase.auth;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        NameEditText = findViewById(R.id.Register_name)
        surnameEditText = findViewById(R.id.Register_surname)
        emailEditText = findViewById(R.id.Register_Email)
        passwordEditText = findViewById(R.id.Register_password)

        val loginbtn =  findViewById<Button>(R.id.login_btn)
        loginbtn.setOnClickListener {

            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
        val registerbtn =  findViewById<Button>(R.id.Register_btn)
        registerbtn.setOnClickListener {
            val email = emailEditText.text.toString()
            val name = NameEditText.text.toString()
            val surname = surnameEditText.text.toString()
            val password = passwordEditText.text.toString()

            val isRegistered = HomeActivity.UserManager.register(email, name, surname, password)
            if (isRegistered) {

                val intent = Intent(this, LoginActivity::class.java)
                Toast.makeText(this, "Registered Successfully", Toast.LENGTH_SHORT).show()
                startActivity(intent)
            } else {
                // Registration failed, email already exists
                val intent = Intent(this, RegisterActivity::class.java)
                startActivity(intent)
            }
            val addOnCompleteListener = auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
                        Log.d(TAG, "createUserWithEmail:success")
                        val user = auth.currentUser
                        updateUI(user)
                    } else {
                        // If sign in fails, display a message to the user.
                        Log.w(TAG, "createUserWithEmail:failure", task.exception)
                        Toast.makeText(
                            baseContext,
                            "Authentication failed.",
                            Toast.LENGTH_SHORT,
                        ).show()
                        updateUI(null)
                    }
                }
        }

    }

    private fun updateUI(user: Any): Any {
        TODO("Not yet implemented")
    }
}