package com.example.projectpacer

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class GoalsActivity : AppCompatActivity() {

    private lateinit var minimumEditText: EditText
    private lateinit var maximumEditText: EditText
    private lateinit var setButton: Button
    private lateinit var goalsSetTextView: TextView
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goals)

        minimumEditText = findViewById(R.id.etMinimum)
        maximumEditText = findViewById(R.id.etMaximum)
        setButton = findViewById(R.id.btnSet)
        goalsSetTextView = findViewById(R.id.tvDailyGoalsSet)

        val loggedInUser = HomeActivity.UserManager.loggedInUser
        if (loggedInUser != null && loggedInUser.isHoursSet()) {
            val minGoalTextView = findViewById<TextView>(R.id.tvMinGoal)
            val maxGoalTextView = findViewById<TextView>(R.id.tvMaxGoal)

            // Set the text for min and max goals
            minGoalTextView.text = "Min hours Goal: ${loggedInUser.minHoursGoal}"
            maxGoalTextView.text = "Max hours Goal: ${loggedInUser.maxHoursGoal}"
        }

        setButton.setOnClickListener {
            val minimum = minimumEditText.text.toString().toIntOrNull()
            val maximum = maximumEditText.text.toString().toIntOrNull()

            if (minimum != null && maximum != null) {
                HomeActivity.UserManager.loggedInUser?.setHours(minimum, maximum)
                goalsSetTextView.text = "Goals set successfully!"
            } else {
                goalsSetTextView.text = "Invalid input. Please enter valid minimum and maximum goals."
            }
        }

        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_home -> {
                    // Handle Home menu item
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }
                R.id.menu_categories -> {
                    // Handle Categories menu item
                    startActivity(Intent(this, CategoriesActivity::class.java))
                    true
                }
                R.id.menu_timesheet -> {
                    // Handle Timesheet menu item
                    startActivity(Intent(this, TimeSheetActivity::class.java))
                    true
                }
                R.id.menu_goals -> {
                    // Handle Goals menu item
                    // do nothing

                    true
                }
                R.id.menu_profile -> {
                    // Handle Goals menu item
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }
}
