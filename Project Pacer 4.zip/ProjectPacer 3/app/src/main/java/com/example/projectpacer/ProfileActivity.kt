package com.example.projectpacer

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView

class ProfileActivity : AppCompatActivity() {
    private lateinit var bottomNavigationView: BottomNavigationView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Set up user details
        val tvName: TextView = findViewById(R.id.tvName)
        val tvEmail: TextView = findViewById(R.id.tvEmail)

        val user = HomeActivity.UserManager.loggedInUser
        tvName.text = user?.name
        tvEmail.text = user?.email

        // Set up log out button
        val btnLogout: Button = findViewById(R.id.btnLogout)
        btnLogout.setOnClickListener {
            showLogoutConfirmationDialog()
        }

        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_home -> {
                    // Handle Home menu item
                    // Example: navigate to HomeActivity or perform other operations
                    true
                }
                R.id.menu_categories -> {
                    // Handle Categories menu item
                    startActivity(Intent(this, CategoriesActivity::class.java))
                    true
                }
                R.id.menu_timesheet -> {
                    // Handle Timesheet menu item
                    startActivity(Intent(this, TimeSheetActivity::class.java))
                    true
                }
                R.id.menu_goals -> {
                    // Handle Goals menu item
                    startActivity(Intent(this, GoalsActivity::class.java))
                    true
                }
                R.id.menu_profile -> {
                    // Handle Goals menu item
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }

    private fun showLogoutConfirmationDialog() {
        val confirmDialog = AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to log out?")
            .setPositiveButton("Yes") { dialog, _ ->
                // User clicked the "Yes" button, proceed with logout
                val logoutSuccessful = HomeActivity.UserManager.logout()

                if (logoutSuccessful) {
                    val intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // Handle the case when the logout was not successful
                    Toast.makeText(this, "Logout failed", Toast.LENGTH_SHORT).show()
                }

                dialog.dismiss()
            }
            .setNegativeButton("No") { dialog, _ ->
                // User clicked the "No" button, dismiss the dialog
                dialog.dismiss()
            }
            .create()

        confirmDialog.show()
    }
}

