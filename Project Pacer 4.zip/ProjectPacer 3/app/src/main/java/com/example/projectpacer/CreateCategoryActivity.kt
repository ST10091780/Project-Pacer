package com.example.projectpacer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CreateCategoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_category)
    }
}