package com.example.projectpacer

class Category {

    //this was taken from YouTube
//author:Programming w/ Professor Sluiter
//Link: https://www.youtube.com/watch?v=4-hK6qZv56U
    data class Category(val name: String,
                        val email: String)

}