package com.example.projectpacer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

//this was taken from YouTube
//author:Programming w/ Professor Sluiter
//Link: https://www.youtube.com/watch?v=4-hK6qZv56U
class timeSheetAdapter(private val timeSheetList: MutableList<TimeSheetData> ) : RecyclerView.Adapter<timeSheetAdapter.timeSheetViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): timeSheetViewHolder {
       val itemView = LayoutInflater.from(parent.context).inflate(R.layout.timesheet_cardview,
       parent, false)

        return timeSheetViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: timeSheetViewHolder, position: Int) {
        val currentItem = timeSheetList[position]



        holder.imageView.setImageBitmap(currentItem.image)
        holder.start_date.text = currentItem.Start_date
        holder.end_date.text = currentItem.End_date
        holder.start_time.text = currentItem.start_time
        holder.end_time.text = currentItem.end_time
        holder.category_name.text = currentItem.category_name
        holder.description.text = currentItem.description

    }

    override fun getItemCount() = timeSheetList.size

    class timeSheetViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){


        val imageView: ImageView = itemView.findViewById(R.id.image_View)
        val start_date: TextView = itemView.findViewById(R.id.startDateTextView)
        val end_date: TextView = itemView.findViewById(R.id.enddateTextView)
        val start_time: TextView = itemView.findViewById(R.id.startTimeTextView)
        val end_time: TextView = itemView.findViewById(R.id.endTimeTextView)
        val category_name: TextView = itemView.findViewById(R.id.categoryTextView)
        val description: TextView = itemView.findViewById(R.id.descriptionTextView)

    }
}