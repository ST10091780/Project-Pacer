package com.example.projectpacer

import android.graphics.Bitmap
import android.os.Parcel
import android.os.Parcelable

//this was taken from YouTube
//author:Programming w/ Professor Sluiter
//Link: https://www.youtube.com/watch?v=4-hK6qZv56U
data class TimeSheetData(
    val image: Bitmap?, val Start_date: String,val End_date: String, val start_time: String,
    val end_time: String, val category_name: String, val description: String, val email : String) : Parcelable{
    constructor(parcel: Parcel) : this(
        parcel.readParcelable(Bitmap::class.java.classLoader),
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: ""


    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeParcelable(image, flags)
        parcel.writeString(Start_date)
        parcel.writeString(End_date)
        parcel.writeString(start_time)
        parcel.writeString(end_time)
        parcel.writeString(category_name)
        parcel.writeString(description)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<TimeSheetData> {
        override fun createFromParcel(parcel: Parcel): TimeSheetData {
            return TimeSheetData(parcel)
        }

        override fun newArray(size: Int): Array<TimeSheetData?> {
            return arrayOfNulls(size)
        }
    }
}