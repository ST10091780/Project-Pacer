package com.example.projectpacer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailEditText = findViewById(R.id.login_Email)
        passwordEditText = findViewById(R.id.login_password)

        val registerbtn = findViewById<Button>(R.id.Register_btn)
        registerbtn.setOnClickListener {

            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
        val loginButton =  findViewById<Button>(R.id.login_btn)
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            val isLoggedIn = HomeActivity.UserManager.login(email, password)
            if (isLoggedIn) {
                // Login successful
                val intent = Intent(this, HomeActivity::class.java)
                Toast.makeText(this, "Logged in Successfully", Toast.LENGTH_LONG).show()
                startActivity(intent)
            } else {
                val intent = Intent(this, LoginActivity::class.java)
                Toast.makeText(this, "Login Failed (Incorrect details)", Toast.LENGTH_LONG).show()
                startActivity(intent)
            }
        }

    }
}