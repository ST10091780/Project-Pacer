package com.example.projectpacer

//this was taken from YouTube
//author:Programming w/ Professor Sluiter
//Link: https://www.youtube.com/watch?v=4-hK6qZv56U
data class User(
    val email: String,
    val name: String,
    val surname: String,
    val password: String,
    var minHoursGoal: Int = 0,
    var maxHoursGoal: Int = 0
) {
    fun setHours(minHours: Int, maxHours: Int) {
        minHoursGoal = minHours
        maxHoursGoal = maxHours
    }

    fun isHoursSet(): Boolean {
        return minHoursGoal != 0 && maxHoursGoal != 0
    }

}