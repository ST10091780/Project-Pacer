package com.example.projectpacer



import com.example.projectpacer.R
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.TextView

//this was taken from YouTube
//author:Programming w/ Professor Sluiter
//Link: https://www.youtube.com/watch?v=4-hK6qZv56U
class CategoriesAdapter(private val activity: CategoriesActivity) : BaseAdapter() {
    private val categoryList = mutableListOf<Category.Category>()

    private var selectedCategory: Category.Category? = null

    override fun getCount(): Int = categoryList.size

    override fun getItem(position: Int): Category.Category = categoryList[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val viewHolder: ViewHolder
        val itemView: View

        if (convertView == null) {
            itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false)
            viewHolder = ViewHolder(itemView)
            itemView.tag = viewHolder
        } else {
            itemView = convertView
            viewHolder = itemView.tag as ViewHolder
        }

        viewHolder.bind(getItem(position), position)
        return itemView
    }

    fun setData(data: List<Category.Category>) {
        categoryList.clear()
        categoryList.addAll(data)
        notifyDataSetChanged()
    }

    fun getSelectedCategory(): Category.Category? {
        return selectedCategory
    }

    private inner class ViewHolder(private val itemView: View) {
        private val categoryTextView: TextView = itemView.findViewById(R.id.categoryTextView)
        private val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)

        fun bind(category: Category.Category, position: Int) {
            categoryTextView.text = category.name

            deleteButton.setOnClickListener {
                activity.deleteCategory(position)
            }

            itemView.setOnClickListener {
                selectedCategory = category
                notifyDataSetChanged()
            }

            // Highlight the selected category
            if (category == selectedCategory) {
                itemView.setBackgroundResource(R.drawable.selected_category_background)
            } else {
                itemView.setBackgroundResource(R.drawable.category_background)
            }
        }
    }
}


