package com.example.projectpacer

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView

class AddCategoryActivity : AppCompatActivity() {
    private lateinit var categoryNameEditText: EditText
    private lateinit var addCategoryButton: Button
    private lateinit var cancelButton: Button
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_category)

        categoryNameEditText = findViewById(R.id.categoryNameEditText)
        addCategoryButton = findViewById(R.id.addCategoryButton)
        cancelButton = findViewById(R.id.cancelButton)

        addCategoryButton.setOnClickListener {
            val categoryName = categoryNameEditText.text.toString().trim()
            if (categoryName.isNotEmpty()) {
                val intent = Intent().apply {
                    putExtra(CategoriesActivity.EXTRA_CATEGORY_NAME, categoryName)
                }
                setResult(Activity.RESULT_OK, intent)
                finish()
            } else {
                Toast.makeText(this, "Please enter a category name", Toast.LENGTH_SHORT).show()
            }
        }


        cancelButton.setOnClickListener {
            onBackPressed()
        }

        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_home -> {
                    // Handle Home menu item
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }
                R.id.menu_categories -> {
                    // Handle Categories menu item
                    startActivity(Intent(this, CategoriesActivity::class.java))
                    true
                }
                R.id.menu_timesheet -> {
                    // Handle Timesheet menu item
                    startActivity(Intent(this, TimeSheetActivity::class.java))
                    true
                }
                R.id.menu_goals -> {
                    // Handle Goals menu item
                    //startActivity(Intent(this, GoalsActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }

    override fun onBackPressed() {
        // Return back to com.example.projectpacer.CategoriesActivity when the back button is pressed
        startActivity(Intent(this, CategoriesActivity::class.java))
        finish()
    }
}
