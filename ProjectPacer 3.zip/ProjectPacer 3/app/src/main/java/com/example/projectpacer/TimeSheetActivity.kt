package com.example.projectpacer

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projectpacer.TimeSheetActivity.TimeSheetManager.timeSheetEntries
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.*
import java.time.format.DateTimeFormatter


//@Suppress("DEPRECATION")
class TimeSheetActivity : AppCompatActivity() {


    private lateinit var newArrayList : List<TimeSheetData>
    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var TimeStartDateButton: Button
    private lateinit var timeEndDateButton: Button
    private lateinit var timeApplyButton: Button

    @RequiresApi(Build.VERSION_CODES.O)
    val dateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_time_sheet)
        val userEmail1 = HomeActivity.UserManager.loggedInUser?.email
        TimeStartDateButton = findViewById(R.id.timeStartDateButton)
        timeEndDateButton = findViewById(R.id.timeEndDateButton)
        timeApplyButton = findViewById(R.id.TimeApplyButton)

        timeApplyButton.setOnClickListener {




            val filteredTimeSheetEntries = timeSheetEntries.filter { entry ->
                val userEmail = HomeActivity.UserManager.loggedInUser?.email
                val entryStartDate: LocalDate = LocalDate.parse(entry.Start_date, dateFormatter)
                val entryEndDate: LocalDate = LocalDate.parse(entry.End_date, dateFormatter)

                // Compare the entry's start and end dates with the specified range
                entryStartDate >= LocalDate.parse(TimeStartDateButton.text, dateFormatter)
                        && entryEndDate <= LocalDate.parse(timeEndDateButton.text, dateFormatter)
                        && userEmail ==entry.email
            }

            // Use filteredTimeSheetEntries in RecyclerView
            val recyclerView: RecyclerView = findViewById(R.id.recycler_view)
            recyclerView.adapter = timeSheetAdapter(filteredTimeSheetEntries as MutableList<TimeSheetData>)

        }

        TimeStartDateButton.setOnClickListener {
            showDatePickerDialog(true)
        }

        timeEndDateButton.setOnClickListener {
            showDatePickerDialog(false)
        }
        newArrayList = timeSheetEntries

        //this was taken from YouTube
        //author:Programming w/ Professor Sluiter
        //Link: https://www.youtube.com/watch?v=4-hK6qZv56U

        // Set up the RecyclerView and adapter
        //val userEmail = "example@example.com" // Specify the email for filtering

        val filteredTimeSheetEntries = timeSheetEntries.filter { entry ->
            entry.email == userEmail1
        }
        val recyclerView: RecyclerView = findViewById(R.id.recycler_view)
        recyclerView.adapter = timeSheetAdapter(filteredTimeSheetEntries as MutableList<TimeSheetData>)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener {
            // Start the new activity here
            val intent = Intent(this, TimeSheetCreation::class.java)

            startActivity(intent)
        }

        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_home -> {
                    // Handle Home menu item
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }
                R.id.menu_categories -> {
                    // Handle Categories menu item
                    startActivity(Intent(this, CategoriesActivity::class.java))
                    true
                }
                R.id.menu_timesheet -> {
                    // Handle Timesheet menu item
                    // do nothing
                    true
                }
                R.id.menu_goals -> {
                    // Handle Goals menu item
                    startActivity(Intent(this, GoalsActivity::class.java))
                    true
                }
                R.id.menu_profile -> {
                    // Handle Goals menu item
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }

    }
    private fun formatDate(year: Int, month: Int, dayOfMonth: Int): String {
        val calendar = Calendar.getInstance()
        calendar.set(year, month, dayOfMonth)
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(calendar.time)
    }

    //this was taken from YouTube
    //author:Coding in FLow
    //Link: https://www.youtube.com/watch?v=33BFCdL0Di0
    private fun showDatePickerDialog(isStartDate: Boolean) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                val selectedDate = formatDate(selectedYear, selectedMonth, selectedDayOfMonth)
                if (isStartDate) {
                    TimeStartDateButton.text = selectedDate
                } else {
                    timeEndDateButton.text = selectedDate
                }
            },
            year,
            month,
            dayOfMonth
        )

        datePickerDialog.show()
    }



    // gloabal time sheet list
    object TimeSheetManager  {
        val timeSheetEntries: MutableList<TimeSheetData> = mutableListOf()
    }
    companion object {
        private const val REQUEST_NEW_TIMESHEET = 1
    }
}