package com.example.projectpacer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {

    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_home -> {
                    // Handle Home menu item
                    // Example: navigate to HomeActivity or perform other operations
                    true
                }
                R.id.menu_categories -> {
                    // Handle Categories menu item
                    startActivity(Intent(this, CategoriesActivity::class.java))
                    true
                }
                R.id.menu_timesheet -> {
                    // Handle Timesheet menu item
                    startActivity(Intent(this, TimeSheetActivity::class.java))
                    true
                }
                R.id.menu_goals -> {
                    // Handle Goals menu item
                    startActivity(Intent(this, GoalsActivity::class.java))
                    true
                }
                R.id.menu_profile -> {
                    // Handle Goals menu item
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }
    object UserManager {
        private val users = mutableListOf<User>()
        var loggedInUser: User? = null
            private set

        fun register(email: String, name: String, surname: String, password: String): Boolean {
            // Check if the email is already registered
            if (users.any { it.email == email }) {
                return false
            }

            // Create a new user and add it to the list
            val user = User(email, name, surname, password)
            users.add(user)
            return true
        }

        fun logout(): Boolean {
            val currentUser = loggedInUser

            // Check if a user is currently logged in
            if (currentUser != null) {
                loggedInUser = null
                return true
            }

            return false
        }

        fun login(email: String, password: String): Boolean {
            // Find the user with the given email
            val user = users.find { it.email == email }

            // Check if the user exists and the password matches
            if (user != null && user.password == password) {
                loggedInUser = user
                return true
            }

            return false
        }
    }

}