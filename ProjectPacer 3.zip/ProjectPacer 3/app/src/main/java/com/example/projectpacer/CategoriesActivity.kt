package com.example.projectpacer

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.projectpacer.CategoriesActivity.CategoriesManager.categoryListFull
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.*

class CategoriesActivity : AppCompatActivity() {

    private lateinit var categoryGridView: GridView
    private lateinit var searchEditText: EditText
    private lateinit var addCategoryButton: Button
    private lateinit var startDateButton: Button
    private lateinit var endDateButton: Button
    private lateinit var applyButton: Button
    private lateinit var bottomNavigationView: BottomNavigationView

    private lateinit var startDate: Date
    private lateinit var endDate: Date
    // Declare your TextViews for displaying total hours
    private lateinit var categoryHoursTextView: TextView

    private val categoryAdapter = CategoriesAdapter(this)
    private val timeEntryList = TimeSheetActivity.TimeSheetManager.timeSheetEntries

    private var selectedCategory: String = ""

    // getting loggin user
    var email = HomeActivity.UserManager.loggedInUser?.email.toString()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categories)
        val userEmail1 = HomeActivity.UserManager.loggedInUser?.email
        categoryGridView = findViewById(R.id.categoryGrid)
        searchEditText = findViewById(R.id.searchEditText)
        addCategoryButton = findViewById(R.id.addCategoryButton)
        startDateButton = findViewById(R.id.startDateButton)
        endDateButton = findViewById(R.id.endDateButton)
        applyButton = findViewById(R.id.applyButton)

        categoryHoursTextView = findViewById(R.id.categoryHoursTextView)

        // Set an OnClickListener for the applyButton
        applyButton.setOnClickListener {
            // Call a method to handle the period selection and calculate total hours
            handlePeriodSelection()
        }

        startDateButton.setOnClickListener {
            showDatePickerDialog(true)
        }

        endDateButton.setOnClickListener {
            showDatePickerDialog(false)
        }

        // Set up the GridView and its adapter
        categoryGridView.adapter = categoryAdapter

        val filteredCategories = categoryListFull.filter { category ->
            category.email == userEmail1
        }
        // Update the category list with all categories
        categoryAdapter.setData(getUniqueCategories(filteredCategories))

        // Handle item click in GridView
        categoryGridView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val selectedCategory = categoryAdapter.getItem(position)
            // Handle the selected category
            handleSelectedCategory(selectedCategory)
        }

        // Handle search
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterCategories(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        // Handle add category button click
        addCategoryButton.setOnClickListener {
            val intent = Intent(this@CategoriesActivity, AddCategoryActivity::class.java)
            startActivityForResult(intent, REQUEST_ADD_CATEGORY)
        }


        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_home -> {
                    // Handle Home menu item
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }
                R.id.menu_categories -> {
                    // Do nothing, already in com.example.projectpacer.CategoriesActivity
                    true
                }
                R.id.menu_timesheet -> {
                    // Handle Timesheet menu item
                    startActivity(Intent(this, TimeSheetActivity::class.java))
                    true
                }
                R.id.menu_goals -> {
                    // Handle Goals menu item
                    startActivity(Intent(this, GoalsActivity::class.java))
                    true
                }
                R.id.menu_profile -> {
                // Handle Goals menu item
                startActivity(Intent(this, ProfileActivity::class.java))
                true
            }
                else -> false
            }
        }
    }

    private fun showDatePickerDialog(isStartDate: Boolean) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                val selectedDate = formatDate(selectedYear, selectedMonth, selectedDayOfMonth)
                if (isStartDate) {
                    startDateButton.text = selectedDate
                } else {
                    endDateButton.text = selectedDate
                }
            },
            year,
            month,
            dayOfMonth
        )

        datePickerDialog.show()
    }

    fun getSelectedCategoryValue(): String {
        return selectedCategory
    }

    private fun setSelectedCategory(categoryName: String) {
        selectedCategory = categoryName
    }

    private fun formatDate(year: Int, month: Int, dayOfMonth: Int): String {
        val calendar = Calendar.getInstance()
        calendar.set(year, month, dayOfMonth)
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(calendar.time)
    }

    private fun filterCategories(query: String) {
        val filteredList = categoryListFull.filter {
            it.name.contains(query, ignoreCase = true)
        }
        categoryAdapter.setData(getUniqueCategories(filteredList))
    }

    private fun handlePeriodSelection() {
        // Get the selected start and end dates from the buttons
        val startDate = startDateButton.text.toString()
        val endDate = endDateButton.text.toString()

        // Get the selected category
        val selectedCategory = categoryAdapter.getSelectedCategory()

        if (selectedCategory != null) {
            // Call a method to calculate the total hours spent on the selected category during the selected period
            val totalHours = calculateTotalHoursForCategory(selectedCategory, startDate, endDate)

            // Update the TextView with the calculated total hours
            categoryHoursTextView.text = "${selectedCategory.name}: $totalHours hours"
        } else {
            // No category selected
            categoryHoursTextView.text = ""
        }
    }

    private fun calculateTotalHoursForCategory(category: Category.Category, startDate: String, endDate: String): Int {
        var totalHours = 0

        // Iterate through the list of time entries
        for (timeEntry in timeEntryList) {
            // Check if the time entry belongs to the specified category
            if (timeEntry.category_name == category.name) {
                val entryStartDate = timeEntry.start_time
                val entryEndDate = timeEntry.end_time

                // Check if the time entry falls within the selected period
                if (entryStartDate >= startDate && entryEndDate <= endDate) {
                    // Calculate the duration of the time entry in hours
                    val duration = calculateDurationInHours(entryStartDate, entryEndDate)
                    totalHours += duration
                }
            }
        }

        return totalHours
    }

    private fun calculateDurationInHours(startDate: String, endDate: String): Int {
        // Perform the calculation to get the duration between the start and end dates in hours
        // You can use a library like Joda-Time or the built-in Date and Time APIs to calculate the duration
        // For simplicity, this example assumes that the start and end dates are in a specific format (e.g., "yyyy-MM-dd HH:mm")
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val startTime = dateFormat.parse(startDate)
        val endTime = dateFormat.parse(endDate)
        val durationInMillis = endTime.time - startTime.time
        val durationInHours = (durationInMillis / (1000 * 60 * 60)).toInt()
        return durationInHours
    }

    private fun handleSelectedCategory(category: Category.Category) {
        setSelectedCategory(category.name)
        // Update the UI to indicate the selected category, such as changing the background color of the selected item in the GridView
    }

    fun deleteCategory(position: Int) {
        if (position in 0 until categoryListFull.size) {
            categoryListFull.removeAt(position)
            categoryAdapter.setData(getUniqueCategories(categoryListFull))
        }
    }

    private fun getUniqueCategories(categoryList: List<Category.Category>): List<Category.Category> {

        // Use a set to store unique categories

        val uniqueCategories = HashSet<String>()

        for (category in categoryList) {
            uniqueCategories.add(category.name)
        }

        return uniqueCategories.map { categoryName -> Category.Category(categoryName,email) }
    }

    object CategoriesManager  {
         val categoryListFull = mutableListOf<Category.Category>()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ADD_CATEGORY && resultCode == RESULT_OK) {
            val categoryName = data?.getStringExtra(EXTRA_CATEGORY_NAME)
            if (!categoryName.isNullOrEmpty()) {
                val newCategory = Category.Category(categoryName,email)
                categoryListFull.add(newCategory)
                categoryAdapter.setData(categoryListFull)
            }
        }
    }

    companion object {
        private const val REQUEST_ADD_CATEGORY = 1
        const val EXTRA_CATEGORY_NAME = "category_name"
    }

}
