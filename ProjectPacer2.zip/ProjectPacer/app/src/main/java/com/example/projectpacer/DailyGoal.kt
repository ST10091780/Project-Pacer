package com.example.projectpacer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class DailyGoal : AppCompatActivity(), View.OnClickListener {
    private lateinit var etMinimum: EditText
    private lateinit var etMaximum: EditText
    private lateinit var btnSet: Button
    private lateinit var tvDailyGoalsSet: TextView
    private val user: User = User()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_goal)

        etMinimum = findViewById(R.id.etMinimum)
        etMaximum = findViewById(R.id.etMaximum)
        btnSet = findViewById(R.id.btnSet)
        tvDailyGoalsSet = findViewById(R.id.tvDailyGoalsSet)

        // Set the button click listener to this activity
        btnSet.setOnClickListener(this)

        // Hard-coded for this instance
        user.username = "johndoe"
        user.name = "John"
        user.surname = "Doe"
        user.email = "johndoe@example.com"
    }

    override fun onClick(view: View) {
        if (view.id == R.id.btnSet) {
            val minHours = etMinimum.text.toString().toIntOrNull()
            val maxHours = etMaximum.text.toString().toIntOrNull()

            if (minHours != null && maxHours != null) {
                user.setHours(minHours, maxHours)

                if (user.isHoursSet()) {
                    val hoursText = getString(R.string.daily_goals_text, user.minHoursGoal, user.maxHoursGoal)
                    tvDailyGoalsSet.text = hoursText

                    val toastMessage = "Minimum Hours: ${user.minHoursGoal}\nMaximum Hours: ${user.maxHoursGoal}"
                    Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter valid minimum and maximum hours", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

class User {
    var username: String = ""
    var name: String = ""
    var surname: String = ""
    var minHoursGoal: Int = 0
    var maxHoursGoal: Int = 0
    var email: String = ""

    fun setHours(minHours: Int, maxHours: Int) {
        minHoursGoal = minHours
        maxHoursGoal = maxHours
    }

    fun isHoursSet(): Boolean {
        return minHoursGoal != 0 && maxHoursGoal != 0
    }
}
