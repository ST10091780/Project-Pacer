package com.example.projectpacer;

import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity
{
    EditText loginUsername, loginPassword;
    Button loginButton;
    TextView registerText;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginUsername = findViewById(R.id.etUsername);
        loginPassword = findViewById(R.id.etPassword);
        loginButton = findViewById(R.id.btnLogin);
        registerText = findViewById(R.id.btnLogin);
    }
    public Boolean validateUsername(){
        String val = loginUsername.getText().toString();

        if(val.isEmpty()){
            loginUsername.setError("Username cannot be empty");
            return false;
        }
        else{
            loginUsername.setError(null);
            return true;
        }
    }
    public Boolean validatePassword(){
        String val = loginPassword.getText().toString();

        if(val.isEmpty()){
            loginPassword.setError("Password  cannot be empty");
            return false;
        }
        else{
            loginPassword.setError(null);
            return true;
        }
    }
}
