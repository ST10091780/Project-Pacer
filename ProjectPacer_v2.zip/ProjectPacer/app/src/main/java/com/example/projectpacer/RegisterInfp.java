package com.example.projectpacer;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterInfp extends AppCompatActivity {

    EditText registerName, registerUsername, registerSurname, registerEmail, registerPassword;
    TextView registration;
    Button registerButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        registerUsername = findViewById(R.id.editUsername);
        registerSurname = findViewById(R.id.editSurname);
        registerEmail = findViewById(R.id.editEmail);
        registerPassword = findViewById(R.id.editPassword);
        registerName = findViewById(R.id.editName);
        registration = findViewById(R.id.tvRegisterHeading);

        registerButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view){

                String name = registerName.getText().toString();
                String surname = registerSurname.getText().toString();
                String email = registerEmail.getText().toString();
                String password = registerPassword.getText().toString();
                String username = registerUsername.getText().toString();

                HelperClass helperclass = new HelperClass(name, surname, username, password, email);
                Toast.makeText(RegisterInfp.this, "You have signup successfully" , Toast.LENGTH_SHORT).show();
                Intent intent = new Intent (RegisterInfp.this, Log.class);
                startActivity(intent);
            }
        });
    }
}

  // registerUsername = findViewById()

